

<header class="main-header">
    
    
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <!-- Header / Nav -->
    <div class="header-inner">
        <div class="container">
            <nav class="navbar navbar-expand-lg navbar-light">
                <a class="navbar-brand d-flex align-items-center" href="<?php echo e(route('home')); ?>">
                    <img src="<?php echo e(asset('images/logo.png')); ?>" alt="Logo" class="img-fluid me-2 logo-img">
                </a>
                <div class="collapse navbar-collapse justify-content-between">
                    <ul class="navbar-nav main-menu mx-auto">
                        <li class="nav-item <?php echo e(Request::path() == 'home' ? 'active' : ''); ?>">
                            <a class="nav-link" href="<?php echo e(route('home')); ?>"><?php echo app('translator')->get('home.home'); ?></a>
                        </li>
                        <li class="nav-item <?php if(Request::path() == 'product-grids' || Request::path() == 'product-lists'): ?> active <?php endif; ?>">
                            <a class="nav-link" href="<?php echo e(route('product-grids')); ?>"><?php echo app('translator')->get('home.gallery'); ?></a>
                        </li>
                        <li class="nav-item <?php echo e(Request::path() == 'about-us' ? 'active' : ''); ?>">
                            <a class="nav-link" href="<?php echo e(route('about-us')); ?>"><?php echo app('translator')->get('home.about_us'); ?></a>
                        </li>
                        <li class="nav-item <?php echo e(Request::path() == 'blog' ? 'active' : ''); ?>">
                            <a class="nav-link" href="<?php echo e(route('blog')); ?>"><?php echo app('translator')->get('home.blog'); ?></a>
                        </li>
                        <li class="nav-item <?php echo e(Request::path() == 'contact' ? 'active' : ''); ?>">
                            <a class="nav-link" href="<?php echo e(route('contact')); ?>"><?php echo app('translator')->get('home.contact'); ?></a>
                        </li>
                    </ul>

                    <!-- Tools -->
                    <div class="d-flex align-items-center">
                        <select class="form-select-sm me-2 lang-select" onchange="changeLanguage(this)"style="display: block;">
                            <option value=""><?php echo app('translator')->get('home.language'); ?></option>
                            <option value="hi" <?php echo e(app()->getLocale() == 'hi' ? 'selected' : ''); ?>><?php echo app('translator')->get('home.hindi'); ?></option>
                            <option value="en" <?php echo e(app()->getLocale() == 'en' ? 'selected' : ''); ?>><?php echo app('translator')->get('home.english'); ?></option>
                            <option value="bn" <?php echo e(app()->getLocale() == 'bn' ? 'selected' : ''); ?>><?php echo app('translator')->get('home.bengali'); ?></option>
                        </select>

                        <!-- <a href="<?php echo e(url('lang/hi')); ?>" class="lang-code me-2 <?php echo e(app()->getLocale() == 'hi' ? 'fw-bold text-primary' : ''); ?>">HN</a>
                        <a href="<?php echo e(url('lang/en')); ?>" class="lang-code me-3 <?php echo e(app()->getLocale() == 'en' ? 'fw-bold text-primary' : ''); ?>">EN</a>
                        <a href="#">
                            <img src="<?php echo e(asset('images/search.png')); ?>" class="icon-img me-3" alt="Search">
                        </a> -->

                        <ul class="list-inline mb-0">
                            <?php if(auth()->guard()->check()): ?>
                                <?php if(Auth::user()->role === 'admin'): ?>
                                    <li class="list-inline-item"><i class="ti-user"></i> <a href="<?php echo e(route('admin')); ?>" target="_blank"><?php echo app('translator')->get('home.dashboard'); ?></a></li>
                                <?php else: ?>
                                    <a href="<?php echo e(route('cart')); ?>"><img src="<?php echo e(asset('images/cart.png')); ?>" class="icon-img me-3" alt="Cart"></a>
                                    <li class="list-inline-item"><i class="ti-user"></i> <a href="<?php echo e(route('user')); ?>" target="_blank"><?php echo app('translator')->get('home.dashboard'); ?></a></li>
                                <?php endif; ?>
                                <li class="list-inline-item"><i class="ti-power-off"></i> <a href="<?php echo e(route('user.logout')); ?>"><?php echo app('translator')->get('home.logout'); ?></a></li>
                            <?php else: ?>
                                <li class="list-inline-item"><i class="ti-power-off"></i>
                                    <a href="<?php echo e(route('login.form')); ?>"><?php echo app('translator')->get('home.login'); ?></a> / 
                                    <a href="<?php echo e(route('register.form')); ?>"><?php echo app('translator')->get('home.register'); ?></a>
                                </li>
                            <?php endif; ?>
                        </ul>
                    </div>
                </div>
            </nav>
        </div>
    </div>

</header>

<script>
    function changeLanguage(select) {
        const lang = select.value;
        if (lang) {
            window.location.href = `/lang/${lang}`;
        }
    }
</script>





<!-- <header class="header shop">
    <div class="topbar">
        <div class="container">
            <div class="row">
                <div class="col-lg-6 col-md-12 col-12">
                    <div class="top-left">
                        <ul class="list-main">
                            <?php
                                $settings=DB::table('settings')->get();
                                
                            ?>
                            <li><i class="ti-headphone-alt"></i><?php $__currentLoopData = $settings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php echo e($data->phone); ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></li>
                            <li><i class="ti-email"></i> <?php $__currentLoopData = $settings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php echo e($data->email); ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></li>
                        </ul>
                    </div>
                </div>
                <div class="col-lg-6 col-md-12 col-12">
                    <div class="right-content">
                        <ul class="list-main">
                        <li><i class="ti-location-pin"></i> <a href="<?php echo e(route('order.track')); ?>">Track Order</a></li>
                            
                            <?php if(auth()->guard()->check()): ?> 
                                <?php if(Auth::user()->role=='admin'): ?>
                                    <li><i class="ti-user"></i> <a href="<?php echo e(route('admin')); ?>"  target="_blank">Dashboard</a></li>
                                <?php else: ?> 
                                    <li><i class="ti-user"></i> <a href="<?php echo e(route('user')); ?>"  target="_blank">Dashboard</a></li>
                                <?php endif; ?>
                                <li><i class="ti-power-off"></i> <a href="<?php echo e(route('user.logout')); ?>">Logout</a></li>

                            <?php else: ?>
                                <li><i class="ti-power-off"></i><a href="<?php echo e(route('login.form')); ?>">Login /</a> <a href="<?php echo e(route('register.form')); ?>">Register</a></li>
                            <?php endif; ?>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="middle-inner">
       
    </div>
    <div class="header-inner">
        <div class="container">
            <div class="cat-nav-head">
                <div class="row">
                    <div class="col-lg-12 col-12">
                        <div class="menu-area">
                            <nav class="navbar navbar-expand-lg">
                                <div class="navbar-collapse">	
                                    <div class="nav-inner">	
                                        <ul class="nav main-menu menu navbar-nav">
                                            <li class="<?php echo e(Request::path()=='home' ? 'active' : ''); ?>"><a href="<?php echo e(route('home')); ?>">Home</a></li>
                                            <li class="<?php echo e(Request::path()=='about-us' ? 'active' : ''); ?>"><a href="<?php echo e(route('about-us')); ?>">About Us</a></li>
                                            <li class="<?php if(Request::path()=='product-grids'||Request::path()=='product-lists'): ?>  active  <?php endif; ?>"><a href="<?php echo e(route('product-grids')); ?>">Products</a><span class="new">New</span></li>												
                                                <?php echo e(Helper::getHeaderCategory()); ?>

                                            <li class="<?php echo e(Request::path()=='blog' ? 'active' : ''); ?>"><a href="<?php echo e(route('blog')); ?>">Blog</a></li>									
                                               
                                            <li class="<?php echo e(Request::path()=='contact' ? 'active' : ''); ?>">
                                                <a href="<?php echo e(route('contact')); ?>">Contact Us</a></li>
                                        </ul>
                                    </div>
                                </div>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</header> -->


<?php /**PATH D:\Project\ecom-main\ecom-main\resources\views/frontend/layouts/header.blade.php ENDPATH**/ ?>
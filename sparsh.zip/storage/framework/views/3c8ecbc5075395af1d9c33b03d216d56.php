<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<?php if(session('success')): ?>
<script>
    Swal.fire({
        title: 'Success!',
        text: '<?php echo e(session('success')); ?>',
        icon: 'success',
        confirmButtonText: 'OK'
    });
</script>
<?php endif; ?>

<?php if(session('error')): ?>
    <script>
        Swal.fire({
            icon: 'error',
            title: 'Oops...',
            text: '<?php echo e(session('error')); ?>',
            confirmButtonColor: '#d33'
        });
    </script>
<?php endif; ?><?php /**PATH D:\Project\ecom-main\ecom-main\resources\views/frontend/layouts/notification.blade.php ENDPATH**/ ?>
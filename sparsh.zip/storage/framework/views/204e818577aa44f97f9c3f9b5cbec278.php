

<?php $__env->startSection('title','E-Paninting || HOME PAGE'); ?>
<?php $__env->startSection('main-content'); ?>
    <!-- subbanner sec start -->
    

    <style>
    .blog-sec {
        padding: 60px 20px;
        background: #fff;
        }

        .container {
            max-width: 90rem;
            margin: 0 auto;
        }

        .blog-heading {
            text-align: center;
            font-size: 36px;
            margin-bottom: 50px;
        }

        .blog-row {
            display: flex;
            gap: 40px;
            justify-content: center;
            flex-wrap: wrap;
        }

        .blog-card {
            flex: 0 0 30%;
            background: #fff;
            text-align: center;
            position: relative;
        }

        .blog-image-wrapper {
            position: relative;
            overflow: hidden;
        }

        .blog-image-wrapper img  {
            width: 100%;
            height: auto;
            display: block;
            transition: transform 0.4s ease;
            border-radius: 10px;
        }
        .blog-image {
            width: 100%;
            height: auto;
            display: block;
        }

        .blog-label {
            position: absolute;
            top: 10px;
            left: 10px;
            background: black;
            color: #fff;
            font-size: 14px;
            padding: 6px 15px;
            font-weight: bold;
            border-radius: 4px;
        }

        .blog-title {
            font-size: 22px;
            margin: 20px 0 15px;
            padding: 0 10px;
        }

        .read-more {
            display: inline-flex;
            align-items: center;
            font-weight: bold;
            color: black;
            text-decoration: none;
            margin-top: 10px;
            font-size: 16px;
        }

        .read-more .arrow {
        margin-left: 5px;
        font-size: 18px;
        transition: transform 0.3s ease;
        }

        .read-more:hover .arrow {
        transform: translateX(5px);
        }


    .product-card {
        position: relative;
        background: #fff;
        border-radius: 10px;
        overflow: hidden;
        transition: all 0.3s ease;
        box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.1);
        }

        .product-img-wrapper {
            position: relative;
            overflow: hidden;
            border-radius: 10px;
        }

        .product-img-wrapper img {
            width: 100%;
            height: auto;
            display: block;
            transition: transform 0.4s ease;
            border-radius: 10px;
        }

        .product-hover-icons {
            position: absolute;
            top: 90%;
            left: 50%;
            transform: translate(-50%, -50%);
            display: flex;
            gap: 10px;
            opacity: 0;
            transition: all 0.2s ease;
        }

        .product-hover-icons button {
            background: #fff;
            border: none;
            border-radius: 5px;
            padding: 8px 10px;
            cursor: pointer;
            font-size: 14px;
            color: #333;
            box-shadow: 0px 2px 6px rgba(0, 0, 0, 0.15);
        }

        .product-card:hover .product-img-wrapper img {
            transform: scale(1.1);
        }

        .product-card:hover .product-hover-icons {
        opacity: 1;
        }

        .product-details {
            
            padding: 10px 5px;
        }

        .product-title {
            font-size: 16px;
            font-weight: 500;
            color: #333;
            margin-bottom: 5px;
        }

        .product-price {
            font-size: 14px;
            color: #000;
        }

    .featured-item {
        position: relative;
        overflow: hidden;
        border-radius: 10px;
    }

    .featured-img {
        position: relative;
    }

    .featured-img img {
        width: 100%;
        height: auto;
        display: block;
        border-radius: 10px;
        transition: transform 0.4s ease;
    }

        .featured-overlay {
            position: absolute;
            bottom: 0;
            left: 0;
            right: 0;
            background: rgba(0, 0, 0, 0.7);
            color: #fff;
            text-align: center;
            padding: 10px;
            opacity: 0;
            transition: opacity 0.3s ease;
            border-bottom-left-radius: 10px;
            border-bottom-right-radius: 10px;
        }

        .featured-item:hover img {
        transform: scale(1.05);
        }

        .featured-item:hover .featured-overlay {
        opacity: 1;
        }

        .featured-overlay h4 {
        font-size: 16px;
        margin: 0;
        }

</style>

    <section class="feature-sec sectionpadding">
        <div class="container">
            <div class="row">
            <div class="col-lg-12">
                <div class="section-heading">
                <h1 class="text-center mt-5"><strong>Necklace Set</strong></h1>
                </div>
            </div>

            <div class="featured-slider owl-carousel">
                <?php
                $product_listss = DB::table('products')->where('status', 'active')->orderBy('id', 'DESC')->limit(6)->get();
                ?>

                <?php $__currentLoopData = $product_listss; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="featured-item">
               <a href="<?php echo e(route('product-detail',$product->slug)); ?>">
                    <div class="featured-img">
                    <?php
                        $photos = json_decode($product->photo);
                    ?>
                    <?php if(!empty($photos) && isset($photos[0])): ?>
                        <img src="<?php echo e(asset($photos[0])); ?>" alt="<?php echo e($product->title); ?>" class="img-fluid">
                    <?php endif; ?>
                    <div class="featured-overlay">
                        <h4 class="title"><?php echo e($product->title); ?></h4>
                    </div>
                    </div>
                </a>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>
            </div>
        </div>
    </section>

    <!-- subbanner sec end -->

    <!-- gallery listing sec start -->
    <section class="gallery-sec sectionpadding">
        



        

        




    </section>
    <!-- gallery listing sec end -->



   <!-- footer sec start -->

    <footer>

   <!-- instagram sec start -->
   
   <!-- instagram sec end -->

   <!-- follow sec start -->
   
   <!-- follow sec end -->

   <!-- footer links sec start  -->
   
   <!-- footer links sec end  -->

   <!-- copyright sec start -->
   
   <!-- copyright sec end -->
   
   </footer>
   <!-- footer sec start -->

   



    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.1/jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.9.0/slick.min.js"></script>   
    <script src="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@fancyapps/ui@5.0/dist/fancybox/fancybox.umd.js"></script>
    <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
    <script src="js/jquery.ripples.js"></script>
    <script src="js/custom.js"></script>  
    <script>
        // Fancybox Config
Fancybox.bind('[data-fancybox]', {
  //
}); 
    </script>
    <script>
        AOS.init();
      </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Project\sparsh\sparsh\resources\views/frontend/pages/product-grids.blade.php ENDPATH**/ ?>
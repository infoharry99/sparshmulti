<?php $__env->startSection('title','Cart Page'); ?>
<?php $__env->startSection('main-content'); ?>
	<!-- Breadcrumbs -->
	<div class="breadcrumbs">
		<div class="container">
			<div class="row">
				<div class="col-12">
					<div class="bread-inner">
						<ul class="bread-list">
							<li><a href="<?php echo e(('home')); ?>">Home<i class="ti-arrow-right"></i></a></li>
							<li class="active"><a href="">Cart</a></li>
						</ul>
					</div>
				</div>
			</div>
		</div>
	</div>
	<!-- End Breadcrumbs -->
	<style>
		.payment-card {
			/* width: 300px; */
			padding: 24px;
			margin-top: 20px;
			border: 1px solid #eee;
			border-radius: 12px;
			font-family: Arial, sans-serif;
			background-color: #fff;
			box-shadow: 0 0 10px rgba(0,0,0,0.05);
			}

			.payment-card h4 {
			font-size: 18px;
			margin-bottom: 20px;
			font-weight: 600;
			}

			.payment-row {
			display: flex;
			justify-content: space-between;
			margin: 10px 0;
			font-size: 15px;
			}

			.payment-row.total {
			font-weight: bold;
			border-top: 1px solid #ddd;
			padding-top: 10px;
			margin-top: 15px;
			}

			.discount {
			color: green;
			}

			.savings-text {
			color: green;
			font-size: 14px;
			margin-top: 10px;
			font-weight: 500;
			text-align: right;
			}

			.place-order-btn {
			width: 100%;
			margin-top: 20px;
			padding: 14px 0;
			background-color: #D64933;
			color: white;
			border: none;
			border-radius: 30px;
			font-size: 16px;
			font-weight: bold;
			cursor: pointer;
			transition: background-color 0.3s ease;
			}

			.place-order-btn:hover {
			background-color: #bf3e2b;
			}

	</style>
	<section class="cart-sec sectionpadding">
		<div class="container">
			<div class="row">
				<div class="col-lg-12">
					<div class="section-heading">
						<h3 class="mb-4">My Cart</h3>
					</div>
				</div>
				<div class="col-lg-8">
					<div class="cart-areas">
						<div class="cart-heading">
							<div class="c-head-text">
								<h6>Hyperlocal Basket (2)</h6>
								<span>Free delivery on order above $500</span>
							</div>
							<div class="c-head-text">
								<h6 class="ct-price"><?php echo e(number_format(Helper::totalCartPrice(),2)); ?></h6>
							</div>
						</div>
						<?php
							$cart_items = Helper::getAllProductFromCart();
						?>
						<div class="cart-item">
							<form action="<?php echo e(route('cart.update')); ?>" method="POST">
								<?php echo csrf_field(); ?>
									<?php if(count($cart_items) > 0): ?>
											<?php $__currentLoopData = Helper::getAllProductFromCart(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$cart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
													<?php
													$photos = json_decode($cart->product['photo']);
													?>
											<div class="cart-img-ct">
												<div class="cart-img">
													<img src="<?php echo e($photos[0]); ?>" class="img-fluid">
												</div>
												<div class="cart-item-content">
													<h6 class="cart-pd-heading"><?php echo e($cart->product['title']); ?></h6>
													<h6>Code: HF4328754</h6>
													<p>Size: 36 X 36 in <br><?php echo ($cart['summary']); ?></p>
													<h4>$<?php echo e(number_format($cart['price'],2)); ?></h4>
													<p class="save-price" data-title="Price">You Save $20.00</p>
												</div>
												<div class="cart-qty">
													<div class="qty-container">
														<button class="qty-btn-minus" type="button" data-type="minus" data-field="quant[<?php echo e($key); ?>]" >
															<i class="fa fa-minus"></i></button>
														<!-- <input type="text" name="qty" value="1" class="input-qty"/> -->
														<input type="text" name="quant[<?php echo e($key); ?>]" class="input-number input-qty"  data-min="1" data-max="100" value="<?php echo e($cart->quantity); ?>">
														<button class="qty-btn-plus" type="button"  data-type="plus" data-field="quant[<?php echo e($key); ?>]"><i class="fa fa-plus"></i></button>
													</div>
													<p>Save for Later</p>
												</div>
											</div>
											<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									<?php else: ?>
										<tr>
											<td class="text-center">
												There are no any carts available. <a href="<?php echo e(route('product-grids')); ?>" style="color:blue;">Continue shopping</a>
											</td>
										</tr>
									<?php endif; ?>

							</form>
						</div>
					</div>
				</div>
				<div class="col-lg-4">
					<div class="cart-progress">
						<ul>
							<li><span class="active"><i class="fas fa-check"></i></span><p>Login</p></li>
							<li><span>2</span><p>Submit</p></li>
							<li><span>3</span><p>Submit</p></li>
						</ul>
					</div>
					<div class="payment-card">
						<h4>Payment Details</h4>
						<div class="payment-row">
							<span>MRP Total</span>
							<span><?php echo e(number_format(Helper::totalCartPrice(),2)); ?></span>
						</div>
						<div class="payment-row">
							<span>Product Discount</span>
							<span class="discount">-$20.00</span>
						</div>
						<div class="payment-row">
							<span>Delivery Fee</span>
							<span>$20.00</span>
						</div>
						<?php
							$total_amount=Helper::totalCartPrice();
							if(session()->has('coupon')){
								$total_amount=$total_amount-Session::get('coupon')['value'];
							}
						?>
					
						<div class="payment-row total">
							<span>Total</span>
							<?php if(session()->has('coupon')): ?>
								<span>$<?php echo e(number_format($total_amount,2)); ?></span>
							<?php else: ?>
								<span>$<?php echo e(number_format($total_amount,2)); ?></span>
							<?php endif; ?>
						</div>
						<?php if(session()->has('coupon')): ?>
							<div class="savings-text" data-price="<?php echo e(Session::get('coupon')['value']); ?>">You Save<<strong>
								$<?php echo e(number_format(Session::get('coupon')['value'],2)); ?></strong>
							</div>
						<?php endif; ?>
						<form action="<?php echo e(route('checkout')); ?>" method="GET">
							<button type="submit" class="place-order-btn">Place Order</button>
						</form>
					</div>
				</div>
			</div>
		</div>
	</section>

	<!-- End Shop Newsletter -->

	<!-- Start Shop Newsletter  -->
	<?php echo $__env->make('frontend.layouts.newsletter', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	<!-- End Shop Newsletter -->

<?php $__env->stopSection(); ?>
<?php $__env->startPush('styles'); ?>
	<style>
		li.shipping{
			display: inline-flex;
			width: 100%;
			font-size: 14px;
		}
		li.shipping .input-group-icon {
			width: 100%;
			margin-left: 10px;
		}
		.input-group-icon .icon {
			position: absolute;
			left: 20px;
			top: 0;
			line-height: 40px;
			z-index: 3;
		}
		.form-select {
			height: 30px;
			width: 100%;
		}
		.form-select .nice-select {
			border: none;
			border-radius: 0px;
			height: 40px;
			background: #f6f6f6 !important;
			padding-left: 45px;
			padding-right: 40px;
			width: 100%;
		}
		.list li{
			margin-bottom:0 !important;
		}
		.list li:hover{
			background:#F7941D !important;
			color:white !important;
		}
		.form-select .nice-select::after {
			top: 14px;
		}
	</style>
<?php $__env->stopPush(); ?>
<?php $__env->startPush('scripts'); ?>
	<script src="<?php echo e(asset('frontend/js/nice-select/js/jquery.nice-select.min.js')); ?>"></script>
	<script src="<?php echo e(asset('frontend/js/select2/js/select2.min.js')); ?>"></script>
	<script>
		$(document).ready(function() { $("select.select2").select2(); });
  		$('select.nice-select').niceSelect();
	</script>
	<script>
		$(document).ready(function(){
			$('.shipping select[name=shipping]').change(function(){
				let cost = parseFloat( $(this).find('option:selected').data('price') ) || 0;
				let subtotal = parseFloat( $('.order_subtotal').data('price') );
				let coupon = parseFloat( $('.coupon_price').data('price') ) || 0;
				// alert(coupon);
				$('#order_total_price span').text('$'+(subtotal + cost-coupon).toFixed(2));
			});

		});

	</script>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('frontend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Project\sparsh\sparsh\resources\views/frontend/pages/cart.blade.php ENDPATH**/ ?>
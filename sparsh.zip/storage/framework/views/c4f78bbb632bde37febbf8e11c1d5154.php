<!-- Meta Tag -->
<?php echo $__env->yieldContent('meta'); ?>
<!-- Title Tag  -->
<title><?php echo $__env->yieldContent('title'); ?></title>
<!-- Favicon -->
<link rel="icon" type="image/png" href="images/favicon.png">
<!-- Web Font -->
<link href="https://fonts.googleapis.com/css?family=Poppins:200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i&display=swap" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<link rel="manifest" href="/manifest.json">
<link rel="stylesheet" href="<?php echo e(asset('frontend/css/bootstrap.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('frontend/css/magnific-popup.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('frontend/css/font-awesome.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('frontend/css/jquery.fancybox.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('frontend/css/themify-icons.css')); ?>">
<!-- <link rel="stylesheet" href="<?php echo e(asset('frontend/css/niceselect.css')); ?>"> -->
<link rel="stylesheet" href="<?php echo e(asset('frontend/css/animate.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('frontend/css/flex-slider.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('frontend/css/owl-carousel.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('frontend/css/slicknav.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('frontend/css/jquery-ui.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('frontend/css/reset.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('frontend/css/styles.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('frontend/css/responsive.css')); ?>">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.min.css"/>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.9.0/slick.min.css" />
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css" />
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css"/>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fancyapps/ui@5.0/dist/fancybox/fancybox.css"/>
<link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
<!-- <link rel="stylesheet" href="<?php echo e(asset('/frontend/css/style.css')); ?>"> -->
<link rel="stylesheet" href="<?php echo e(asset('/frontend/css/responstive.css')); ?>">

<!-- <script type='text/javascript' src='https://platform-api.sharethis.com/js/sharethis.js#property=5f2e5abf393162001291e431&product=inline-share-buttons' async='async'></script> -->
<style>
    /* Multilevel dropdown */
    .dropdown-submenu {
    position: relative;
    }
    .sharethis-sticky-share-buttons,
    .sharethis-inline-follow-buttons {
        display: none !important;
    }
    .dropdown-submenu>a:after {
    content: "\f0da";
    float: right;
    border: none;
    font-family: 'Albert Sans', sans-serif !important;
    }

    .dropdown-submenu>.dropdown-menu {
    top: 0;
    left: 100%;
    margin-top: 0px;
    margin-left: 0px;
    }

</style>
<?php echo $__env->yieldPushContent('styles'); ?>
<script>
    window.addEventListener('load', () => {
        setTimeout(() => {
            const stickyBar = document.querySelector('.sharethis-sticky-share-buttons');
            const inlineButtons = document.querySelector('.sharethis-inline-follow-buttons');

            if (stickyBar) stickyBar.style.display = 'none';
            if (inlineButtons) inlineButtons.style.display = 'none';
        }, 10000); 
    });
</script><?php /**PATH D:\Project\sparsh\sparsh\resources\views/frontend/layouts/head.blade.php ENDPATH**/ ?>
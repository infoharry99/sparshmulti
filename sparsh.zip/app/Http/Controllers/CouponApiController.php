<?php

namespace App\Http\Controllers;
use App\Models\Coupon;
use Illuminate\Http\Request;
use App\Models\Cart;

class CouponApiController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $coupon=Coupon::orderBy('id','DESC')->paginate('10');
        return view('backend.coupon.index')->with('coupons',$coupon);
    }

    public function create()
    {
        return view('backend.coupon.create');
    }

    public function store(Request $request)
    {
        // return $request->all();
        $this->validate($request,[
            'code'=>'string|required',
            'type'=>'required|in:fixed,percent',
            'value'=>'required|numeric',
            'status'=>'required|in:active,inactive'
        ]);
        $data=$request->all();
        $status=Coupon::create($data);
        if($status){
            request()->session()->flash('success','Coupon Successfully added');
        }
        else{
            request()->session()->flash('error','Please try again!!');
        }
        return redirect()->route('coupon.index');
    }

    public function show($id)
    {
    }

    public function edit($id)
    {
        $coupon=Coupon::find($id);
        if($coupon){
            return view('backend.coupon.edit')->with('coupon',$coupon);
        }
        else{
            return view('backend.coupon.index')->with('error','Coupon not found');
        }
    }

   
    public function update(Request $request, $id)
    {
        $coupon=Coupon::find($id);
        $this->validate($request,[
            'code'=>'string|required',
            'type'=>'required|in:fixed,percent',
            'value'=>'required|numeric',
            'status'=>'required|in:active,inactive'
        ]);
        $data=$request->all();
        
        $status=$coupon->fill($data)->save();
        if($status){
            request()->session()->flash('success','Coupon Successfully updated');
        }
        else{
            request()->session()->flash('error','Please try again!!');
        }
        return redirect()->route('coupon.index');
        
    }

    public function destroy($id)
    {
        $coupon=Coupon::find($id);
        if($coupon){
            $status=$coupon->delete();
            if($status){
                request()->session()->flash('success','Coupon successfully deleted');
            }
            else{
                request()->session()->flash('error','Error, Please try again');
            }
            return redirect()->route('coupon.index');
        }
        else{
            request()->session()->flash('error','Coupon not found');
            return redirect()->back();
        }
    }

    public function couponStore(Request $request){
        try {
            $validated = $request->validate([
                'user_id' => 'required|exists:users,id',
                'code' => 'required',
            ]);
            $user_id = $request->user_id;
            $coupon  = Coupon::where('code',$request->code)->first();
            if(!$coupon){
                return response()->json([
                    'success' => false, 
                    'data' => null,
                    'message' => "Invalid coupon code, Please try again", 
                    'code' => 400
                ], 400);
            }
            if($coupon){
                $total_price = Cart::where('user_id',$user_id)->where('order_id',null)->sum('price');
                return response()->json([
                    'success' => true, 
                    'value'   => $coupon->discount($total_price),
                    'message' => "Coupon successfully applied", 
                    'code'    => 200
                ], 200);
                // session()->put('coupon',[
                //     'id'=>$coupon->id,
                //     'code'=>$coupon->code,
                //     'value'=>$coupon->discount($total_price)
                // ]);
                // request()->session()->flash('success','Coupon successfully applied');
                // return redirect()->back();
            }
        } catch (\Exception $e) {
            return response()->json([
                'success' => false, 
                'data' => null,
                'message' => $e->getMessage(), 
                'code' => 400
            ], 400);
        }  
    }
}
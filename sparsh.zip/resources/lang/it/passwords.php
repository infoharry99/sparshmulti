<?php return array (
  'password' => 'Le password devono essere di almeno sei caratteri e devono corrispondere alla conferma.',
  'reset' => 'La password &egrave; stata reimpostata!',
  'sent' => 'Abbiamo inviato per e-mail il link per la reimpostazione della password!',
  'token' => 'Il token per la reimpostazione della password non &egrave; valido.',
  'user' => 'Non riusciamo a trovare un utente con quell\'indirizzo e-mail..',
) ?>
<?php return array (
  'next' => 'Siguiente &raquo;',
  'previous' => '&laquo; Anterior',
) ?>
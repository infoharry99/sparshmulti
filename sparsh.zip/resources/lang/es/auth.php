<?php return array (
  'failed' => 'Estas credenciales no coinciden con nuestros registros.',
  'throttle' => 'Demasiados intentos de inicio de sesión. Inténtalo de nuevo en :seconds segundos.',
) ?>
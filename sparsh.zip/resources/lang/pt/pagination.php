<?php return array (
  'next' => 'Próximo &raquo;',
  'previous' => '&laquo; Anterior',
) ?>
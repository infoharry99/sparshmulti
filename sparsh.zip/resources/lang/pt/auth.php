<?php return array (
  'failed' => 'Estas credenciais não coincidem com os nossos registos.',
  'throttle' => 'Demasiadas tentativas de início de sessão. Por favor, tente novamente em :seconds segundos.',
) ?>